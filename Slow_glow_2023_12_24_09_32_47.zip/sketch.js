function setup() {
  createCanvas(400, 400);
   background(220);
  noStroke()
}

function draw() {
  if (mouseIsPressed==true){
  {fill(mouseX,mouseY,100)
  ellipse(mouseX,mouseY,20)}
}
}
